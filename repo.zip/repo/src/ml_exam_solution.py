# ===== PART 1 =====
import pandas as pd, numpy as np, json, warnings
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt, seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             roc_auc_score, confusion_matrix, ConfusionMatrixDisplay)
from imblearn.over_sampling import SMOTE
warnings.filterwarnings("ignore")
sns.set_theme(style="whitegrid", palette=["#2b6cb0", "#dd6b20"])
D = "/mnt/user-data/attachments/71634f9d-498d-5048-9160-80108ad5c846/"
OUT = "/home/claude/work/"
df = pd.read_csv(D + "bd197f4a-us_masters_admission_competitiveness_-_LMS.csv")
T = "admission_competitiveness"
R = {}

# ---------- Q1 EDA ----------
vc = df[T].value_counts().sort_index()
R["target_counts"] = vc.to_dict(); R["target_pct"] = (vc / len(df) * 100).round(1).to_dict()
fig, ax = plt.subplots(figsize=(4.5, 3.5))
ax.bar(["Non-competitive (0)", "Competitive (1)"], vc.values, color=["#dd6b20", "#2b6cb0"])
for i, v in enumerate(vc.values): ax.text(i, v + 40, f"{v} ({v/len(df):.0%})", ha="center")
ax.set_ylabel("Students"); ax.set_title("Target distribution"); plt.tight_layout(); plt.savefig(OUT + "p1_target.png", dpi=150); plt.close()

cats = ["target_university_ranking_band", "ug_university_tier", "visa_dependency", "ug_major",
        "english_test_type", "intended_specialization", "application_round", "preferred_application_city"]
catrate = {}
fig, axs = plt.subplots(2, 4, figsize=(16, 7))
for ax, c in zip(axs.ravel(), cats):
    r = (df.groupby(c)[T].mean() * 100).sort_values(ascending=False)
    catrate[c] = r.round(1).to_dict()
    sns.barplot(x=r.index, y=r.values, ax=ax, color="#2b6cb0"); ax.axhline(30, ls="--", c="#dd6b20", lw=1)
    ax.set_title(c); ax.set_ylabel("% competitive"); ax.tick_params(axis="x", rotation=40)
plt.tight_layout(); plt.savefig(OUT + "p1_cats.png", dpi=130); plt.close()
R["catrate"] = catrate

num = df.select_dtypes("number").drop(columns=[T]).columns.tolist()
grp = df.groupby(T)[num].mean().T; grp["diff_pct"] = ((grp[1] - grp[0]) / grp[0].abs() * 100).round(1)
R["group_means"] = grp.round(2).to_dict("index")
corr_t = df[num + [T]].corr()[T].drop(T).sort_values(key=abs, ascending=False)
R["corr_target"] = corr_t.round(3).to_dict()
key = ["ug_gpa", "gre_quant", "english_proficiency_score", "project_count", "sop_quality_score", "number_of_backlogs"]
fig, axs = plt.subplots(2, 3, figsize=(13, 7))
for ax, c in zip(axs.ravel(), key):
    sns.boxplot(data=df, x=T, y=c, ax=ax, palette=["#dd6b20", "#2b6cb0"]); ax.set_title(c)
plt.tight_layout(); plt.savefig(OUT + "p1_box.png", dpi=130); plt.close()

# ---------- Q2 Cleaning ----------
miss = df.isna().sum(); miss = miss[miss > 0]
R["missing"] = {k: [int(v), round(v / len(df) * 100, 1)] for k, v in miss.items()}
R["skew_missing"] = {k: round(df[k].skew(), 2) for k in miss.index}
R["dups"] = int(df.duplicated().sum())
drop_id = ["student_id"]
X = df.drop(columns=drop_id + [T]); y = df[T]
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)
med = Xtr[miss.index].median()
Xtr = Xtr.copy(); Xte = Xte.copy()
Xtr[miss.index] = Xtr[miss.index].fillna(med); Xte[miss.index] = Xte[miss.index].fillna(med)  # train medians only

# ---------- encoding ----------
tier = {"Tier 3": 1, "Tier 2": 2, "Tier 1": 3}
band = {"Above 100": 1, "Top 100": 2, "Top 50": 3, "Top 20": 4}
def enc(d):
    d = d.copy()
    d["ug_university_tier"] = d["ug_university_tier"].map(tier)
    d["target_university_ranking_band"] = d["target_university_ranking_band"].map(band)
    d["visa_dependency"] = (d["visa_dependency"] == "Yes").astype(int)
    d["application_round"] = (d["application_round"] == "Spring").astype(int)
    d["english_test_type"] = (d["english_test_type"] == "TOEFL").astype(int)
    return d
nominal = ["ug_major", "intended_specialization", "preferred_application_city"]
Xtr_e = pd.get_dummies(enc(Xtr), columns=nominal, drop_first=True, dtype=int)
Xte_e = pd.get_dummies(enc(Xte), columns=nominal, drop_first=True, dtype=int).reindex(columns=Xtr_e.columns, fill_value=0)
R["n_features_after_encoding"] = Xtr_e.shape[1]
sc = StandardScaler().fit(Xtr_e)
Xtr_s = pd.DataFrame(sc.transform(Xtr_e), columns=Xtr_e.columns, index=Xtr_e.index)
Xte_s = pd.DataFrame(sc.transform(Xte_e), columns=Xtr_e.columns, index=Xte_e.index)

# ---------- feature selection ----------
rf0 = RandomForestClassifier(n_estimators=300, random_state=42, n_jobs=-1).fit(Xtr_e, ytr)
imp = pd.Series(rf0.feature_importances_, Xtr_e.columns).sort_values(ascending=False)
R["importance"] = imp.round(4).to_dict()
top = imp.head(15)[::-1]
fig, ax = plt.subplots(figsize=(7, 5.5)); ax.barh(top.index, top.values, color="#2b6cb0")
ax.set_title("Random Forest - top 15 feature importances"); plt.tight_layout(); plt.savefig(OUT + "p1_imp.png", dpi=150); plt.close()
# features with negligible importance (below 1%)  -> candidates to drop
low = imp[imp < 0.005].index.tolist(); R["low_importance"] = low
sel = imp[imp >= 0.005].index.tolist(); R["n_selected"] = len(sel)

# ---------- Q3/Q4 models ----------
def metrics(m, Xa, Xb):
    p = m.predict(Xb); pr = m.predict_proba(Xb)[:, 1]
    return dict(Accuracy=accuracy_score(yte, p), Precision=precision_score(yte, p), Recall=recall_score(yte, p),
                F1=f1_score(yte, p), ROC_AUC=roc_auc_score(yte, pr)), p
models = {"Logistic Regression": (lambda: LogisticRegression(max_iter=2000, random_state=42), True),
          "Decision Tree": (lambda: DecisionTreeClassifier(max_depth=5, min_samples_leaf=20, random_state=42), False),
          "Random Forest": (lambda: RandomForestClassifier(n_estimators=300, max_depth=12, min_samples_leaf=3, random_state=42, n_jobs=-1), False)}
rows = []; preds = {}
Xs_tr, Xs_te = Xtr_s[sel], Xte_s[sel]; Xt_tr, Xt_te = Xtr_e[sel], Xte_e[sel]
for name, (mk, scaled) in models.items():
    m = mk().fit(Xs_tr if scaled else Xt_tr, ytr)
    mt, p = metrics(m, None, Xs_te if scaled else Xt_te); rows.append({"Model": name, "Setting": "Baseline", **mt}); preds[(name, "Baseline")] = p
sm = SMOTE(random_state=42)
Xs_sm, ys_sm = sm.fit_resample(Xs_tr, ytr); Xt_sm, _ = sm.fit_resample(Xt_tr, ytr)
R["smote_counts"] = {"before": ytr.value_counts().sort_index().to_dict(), "after": ys_sm.value_counts().sort_index().to_dict()}
for name, (mk, scaled) in models.items():
    m = mk().fit(Xs_sm if scaled else Xt_sm, ys_sm)
    mt, p = metrics(m, None, Xs_te if scaled else Xt_te); rows.append({"Model": name, "Setting": "SMOTE", **mt}); preds[(name, "SMOTE")] = p
res = pd.DataFrame(rows); res.to_csv(OUT + "p1_results.csv", index=False)
R["results"] = res.round(4).to_dict("records")
# coefficients of LR baseline
lr = LogisticRegression(max_iter=2000, random_state=42).fit(Xs_tr, ytr)
R["lr_coef"] = pd.Series(lr.coef_[0], sel).sort_values(key=abs, ascending=False).head(8).round(3).to_dict()
R["cm"] = {f"{k[0]}|{k[1]}": confusion_matrix(yte, v).tolist() for k, v in preds.items()}
fig, axs = plt.subplots(2, 3, figsize=(12, 7))
for ax, ((n, s), p) in zip(axs.ravel(), preds.items()):
    ConfusionMatrixDisplay(confusion_matrix(yte, p), display_labels=["Non", "Comp"]).plot(ax=ax, colorbar=False, cmap="Blues")
    ax.set_title(f"{n}\n({s})", fontsize=10); ax.grid(False)
plt.tight_layout(); plt.savefig(OUT + "p1_cm.png", dpi=130); plt.close()
R["n_train"], R["n_test"] = len(Xtr), len(Xte)
json.dump(R, open(OUT + "p1.json", "w"), indent=1, default=str)
print(res.round(3).to_string()); print(imp.head(12).round(3)); print(R["missing"], R["skew_missing"]); print(low)
print(grp.round(2).to_string()); print(catrate)

# ===== PART 2 (analysis) =====
import pandas as pd, numpy as np, json, warnings
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt, seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
warnings.filterwarnings("ignore")
sns.set_theme(style="whitegrid", palette=["#2b6cb0", "#dd6b20", "#2f855a", "#805ad5", "#d69e2e"])
D = "/mnt/user-data/attachments/71634f9d-498d-5048-9160-80108ad5c846/"; OUT = "/home/claude/work/"
# "None" in subscription_status is a real category (no Gold plan) - stop pandas reading it as NaN
raw = pd.read_csv(D + "9913355a-zomato_user_data_-_LMS.csv", keep_default_na=False, na_values=[""])
R = {"raw_shape": raw.shape}
nums = raw.select_dtypes("number").columns.tolist(); cats = ["city", "device_type", "subscription_status", "user_segment_label", "preferred_cuisine"]

# ---------- Q1 EDA (on raw, before cleaning) ----------
fig, axs = plt.subplots(4, 4, figsize=(16, 12))
for ax, c in zip(axs.ravel(), nums):
    sns.histplot(raw[c].dropna(), bins=30, ax=ax, color="#2b6cb0"); ax.set_title(c, fontsize=10); ax.set_xlabel("")
plt.tight_layout(); plt.savefig(OUT + "p2_hist.png", dpi=110); plt.close()
R["skew"] = raw[nums].skew().round(2).to_dict()
R["desc"] = raw[nums].describe().T[["mean", "50%", "std", "min", "max"]].round(2).to_dict("index")

# ---------- Q2 quality ----------
R["missing"] = {k: [int(v), round(v / len(raw) * 100, 1)] for k, v in raw.isna().sum().items() if v > 0}
R["dups_full"] = int(raw.duplicated().sum()); R["dups_id"] = int(raw.user_id.duplicated().sum())
df = raw.drop_duplicates().reset_index(drop=True); R["after_dedup"] = len(df)
# can order value be rebuilt from spend / orders ?
m = df.dropna(subset=["avg_order_value"]); m = m[m.orders_per_month > 0.5]
R["spend_check_corr"] = round(float(np.corrcoef(m.orders_per_month * m.avg_order_value, m.monthly_food_spend)[0, 1]), 3)
for c in ["avg_order_value", "discount_usage_rate", "avg_delivery_time_minutes"]:
    df[c] = df[c].fillna(df[c].median())
df["preferred_cuisine"] = df["preferred_cuisine"].fillna("Unknown")
R["after_clean_missing"] = int(df.isna().sum().sum())

# categorical EDA
fig, axs = plt.subplots(2, 3, figsize=(15, 8))
for ax, c in zip(axs.ravel(), cats):
    order = df[c].value_counts().index; sns.countplot(data=df, x=c, order=order, ax=ax, color="#2b6cb0"); ax.tick_params(axis="x", rotation=35); ax.set_title(c)
ax = axs.ravel()[-1]; g = df.groupby("subscription_status")[["orders_per_month", "monthly_food_spend"]].mean()
g.plot.bar(ax=ax, rot=0, color=["#2b6cb0", "#dd6b20"]); ax.set_title("Gold vs non-Gold: mean orders & spend")
plt.tight_layout(); plt.savefig(OUT + "p2_cats.png", dpi=110); plt.close()
R["cat_counts"] = {c: df[c].value_counts().to_dict() for c in cats}
R["by_sub"] = df.groupby("subscription_status")[["orders_per_month", "monthly_food_spend", "app_opens_per_month", "discount_usage_rate"]].mean().round(2).to_dict("index")
R["by_seg"] = df.groupby("user_segment_label")[["orders_per_month", "monthly_food_spend", "app_opens_per_month", "days_since_last_order"]].mean().round(2).to_dict("index")
R["by_device"] = df.groupby("device_type")[["orders_per_month", "monthly_food_spend", "avg_order_value"]].mean().round(2).to_dict("index")
R["by_city"] = df.groupby("city")[["orders_per_month", "monthly_food_spend"]].mean().round(2).to_dict("index")

# outliers IQR
q1, q3 = df[nums].quantile(.25), df[nums].quantile(.75); iqr = q3 - q1
mask = (df[nums] < q1 - 1.5 * iqr) | (df[nums] > q3 + 1.5 * iqr)
R["outliers"] = {k: [int(v), round(v / len(df) * 100, 1)] for k, v in mask.sum().items() if v > 0}
R["rows_with_outlier"] = int(mask.any(axis=1).sum())
fig, ax = plt.subplots(figsize=(14, 5)); sns.boxplot(data=(df[nums] - df[nums].mean()) / df[nums].std(), ax=ax, color="#9ec5e8", fliersize=2)
ax.tick_params(axis="x", rotation=60); ax.set_title("Standardised boxplots - outlier check"); plt.tight_layout(); plt.savefig(OUT + "p2_box.png", dpi=110); plt.close()

# correlation
C = df[nums].corr(); fig, ax = plt.subplots(figsize=(11, 8.5))
sns.heatmap(C, cmap="RdBu_r", center=0, vmin=-1, vmax=1, annot=True, fmt=".2f", annot_kws={"size": 6}, ax=ax); plt.tight_layout(); plt.savefig(OUT + "p2_corr.png", dpi=110); plt.close()
pairs = [(a, b, round(C.loc[a, b], 2)) for i, a in enumerate(nums) for b in nums[i + 1:] if abs(C.loc[a, b]) >= 0.5]
R["pairs"] = sorted(pairs, key=lambda t: -abs(t[2]))

# ---------- Q3 PCA ----------
Z = StandardScaler().fit_transform(df[nums]); pca = PCA().fit(Z); cum = np.cumsum(pca.explained_variance_ratio_)
n90 = int(np.argmax(cum >= .90) + 1); n95 = int(np.argmax(cum >= .95) + 1)
R["pca"] = {"evr": pca.explained_variance_ratio_.round(3).tolist(), "cum": cum.round(3).tolist(), "n90": n90, "n95": n95, "n_features": len(nums)}
fig, ax = plt.subplots(figsize=(7, 4.2)); ax.plot(range(1, len(cum) + 1), cum, marker="o", c="#2b6cb0")
ax.axhline(.9, ls="--", c="#dd6b20"); ax.axhline(.95, ls="--", c="#2f855a"); ax.axvline(n95, ls=":", c="grey")
ax.set(xlabel="Number of principal components", ylabel="Cumulative explained variance", title="PCA cumulative variance"); plt.tight_layout(); plt.savefig(OUT + "p2_pca.png", dpi=150); plt.close()
ncomp = n95; P = PCA(n_components=ncomp).fit(Z); Zp = P.transform(Z)
load = pd.DataFrame(P.components_[:3].T, index=nums, columns=["PC1", "PC2", "PC3"])
R["loadings"] = {pc: load[pc].reindex(load[pc].abs().sort_values(ascending=False).index).head(5).round(2).to_dict() for pc in load}

# ---------- Q4 K-Means ----------
ks = range(1, 11); inertia = []; sil = {}
for k in ks:
    km = KMeans(k, n_init=10, random_state=42).fit(Zp); inertia.append(km.inertia_)
    if k > 1: sil[k] = silhouette_score(Zp, km.labels_)
R["inertia"] = [round(i) for i in inertia]; R["sil"] = {k: round(v, 3) for k, v in sil.items()}
fig, axs = plt.subplots(1, 2, figsize=(11, 4)); axs[0].plot(list(ks), inertia, marker="o", c="#2b6cb0"); axs[0].set(xlabel="k", ylabel="Inertia (WCSS)", title="Elbow curve")
axs[1].plot(list(sil), list(sil.values()), marker="o", c="#dd6b20"); axs[1].set(xlabel="k", ylabel="Silhouette", title="Silhouette (supporting check)")
plt.tight_layout(); plt.savefig(OUT + "p2_elbow.png", dpi=150); plt.close()
json.dump(R, open(OUT + "p2.json", "w"), indent=1, default=str)
np.save(OUT + "Zp.npy", Zp); df.to_pickle(OUT + "zdf.pkl")
print(json.dumps({k: R[k] for k in ["missing", "dups_full", "dups_id", "spend_check_corr", "outliers", "rows_with_outlier", "pairs", "pca", "loadings", "inertia", "sil"]}, indent=0, default=str))
print(R["by_sub"], R["by_seg"], R["by_device"], R["by_city"])

# ===== PART 2 (K-Means) =====
import pandas as pd, numpy as np, json, warnings
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt, seaborn as sns
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
warnings.filterwarnings("ignore")
sns.set_theme(style="whitegrid"); OUT="/home/claude/work/"
df=pd.read_pickle(OUT+"zdf.pkl"); Zp=np.load(OUT+"Zp.npy"); R=json.load(open(OUT+"p2.json"))
nums=df.select_dtypes("number").columns.tolist()
K=4; km=KMeans(K,n_init=10,random_state=42).fit(Zp); df["cluster"]=km.labels_
sz=df.cluster.value_counts().sort_index(); R["sizes"]=sz.to_dict()
prof=df.groupby("cluster")[nums].mean(); R["profile"]=prof.round(2).to_dict("index")
z=(prof-df[nums].mean())/df[nums].std(); R["z"]=z.round(2).to_dict("index")
R["cat_mix"]={c:(pd.crosstab(df.cluster,df[c],normalize="index")*100).round(0).to_dict("index") for c in ["subscription_status","user_segment_label","city"]}
pal=["#2b6cb0","#dd6b20","#2f855a","#805ad5"]
fig,axs=plt.subplots(1,2,figsize=(12,4.5))
axs[0].bar([f"C{i}" for i in sz.index],sz.values,color=pal)
for i,v in enumerate(sz.values): axs[0].text(i,v+15,f"{v} ({v/len(df):.0%})",ha="center")
axs[0].set(title="Users per cluster",ylabel="Users")
for c in range(K): m=df.cluster==c; axs[1].scatter(Zp[m,0],Zp[m,1],s=6,alpha=.5,c=pal[c],label=f"C{c}")
axs[1].set(xlabel="PC1",ylabel="PC2",title="Clusters in PCA space"); axs[1].legend(markerscale=3)
plt.tight_layout(); plt.savefig(OUT+"p2_clusters.png",dpi=150); plt.close()
fig,ax=plt.subplots(figsize=(11,3.8)); sns.heatmap(z.T,cmap="RdBu_r",center=0,annot=True,fmt=".1f",annot_kws={"size":7},ax=ax,cbar_kws={"label":"z-score vs overall mean"})
ax.set_title("Cluster profile (standardised means)"); plt.tight_layout(); plt.savefig(OUT+"p2_profile.png",dpi=140); plt.close()
json.dump(R,open(OUT+"p2.json","w"),indent=1,default=str)
pd.set_option("display.width",250); print(sz.to_dict()); print(z.T.round(2).to_string()); print(prof[["orders_per_month","monthly_food_spend","avg_order_value","app_opens_per_month","days_since_last_order","discount_usage_rate","browse_sessions_without_order"]].round(1))
print(R["cat_mix"]["subscription_status"])
